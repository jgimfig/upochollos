<!--FICHERO DONDE SE INVOCAN TODOS LOS FICHEROS Y LIBRERIAS JS COMUNES AL PROYECTO Y SUS DEPENDENCIAS-->

<!--JQUERY-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!--JQUERY UI-->
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">

<!--FICHERO DE FUNCIONES JA COMÚN A TODO EL PROYECTO-->
<script type="text/javascript" src="../js/funciones.js"></script>