<?php
    header('location: ./php/principal.php');
?>