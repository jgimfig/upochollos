/*
 *  DENTRO DE LA PÁGINA DE PERFIL
 *  
 *   SE HACE LA LLAMADA A ESTE PLUGIN QUE MUESTRA DE UNA FORMA MAS VISTOSA
 *   LAS VISTA EN PESTAÑAS DE LAS SECCIONES 'Noticias guardadas', 'Noticias publicadas'
 *   y 'Comentarios publicados'
 *    
 */

$(document).ready(function ($) {
    $('#tab-container').easytabs();
});


