
<!--IMAGEN DE UNA FLECHA QUE AL SER PULSADA, TRASLADA AL USUARIO AL PRINCIPIO DEL DOCUMENTO-->
<script type="text/javascript" src="../js/comportamientoFlecha.js"></script>

<a id="subir">
    <figure><img src="../img/iconos/iconoFlecha.svg" alt="ir al principio de la página"/></figure>
</a>