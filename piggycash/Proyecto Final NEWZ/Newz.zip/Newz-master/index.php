
<?php
    header('location: ./php/comunidad.php');
?>

